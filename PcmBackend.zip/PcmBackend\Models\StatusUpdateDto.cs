namespace PcmBackend.Models;

public class StatusUpdateDto
{
    public bool IsActive { get; set; }
}
